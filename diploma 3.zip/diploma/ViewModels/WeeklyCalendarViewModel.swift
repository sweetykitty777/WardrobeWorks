import Foundation
import Combine
import SwiftUI

class WeeklyCalendarViewModel: ObservableObject {
    @Published var currentWeek: [CalendarDay] = []
    @Published var selectedDate: Date = Date()
    @Published var clothingStats: [ClothingStat] = []
    @Published var clothingItems: [ClothingItem] = []
    @Published var selectedOutfit: Outfit? = nil
    @Published var selectedScheduledOutfit: ScheduledOutfitResponse? = nil
    @Published var sharedAccesses: [SharedAccess] = []
    @Published var scheduledOutfits: [ScheduledOutfitResponse] = []

    private var calendar: Calendar {
        var calendar = Calendar.current
        calendar.firstWeekday = 2 // Monday
        return calendar
    }

    var weekRange: String {
        guard let startOfWeek = currentWeek.first?.date,
              let endOfWeek = currentWeek.last?.date else { return "" }
        return "\(startOfWeek.formattedShort) - \(endOfWeek.formattedShort)"
    }

    func updateCurrentWeek() {
        guard let weekInterval = calendar.dateInterval(of: .weekOfYear, for: selectedDate) else { return }
        let today = Date()

        currentWeek = (0..<7).compactMap { offset in
            if let date = calendar.date(byAdding: .day, value: offset, to: weekInterval.start) {
                return CalendarDay(
                    date: date,
                    isSelected: calendar.isDate(date, inSameDayAs: selectedDate),
                    isToday: calendar.isDate(date, inSameDayAs: today)
                )
            }
            return nil
        }

        fetchScheduledOutfits { result in
            switch result {
            case .success(let fetched):
                self.scheduledOutfits = fetched
                self.selectedScheduledOutfit = fetched.first {
                    self.calendar.isDate($0.date, inSameDayAs: self.selectedDate)
                }
            case .failure(let error):
                print("❌ Не удалось загрузить запланированные аутфиты: \(error.localizedDescription)")
            }
        }
    }


    func selectDate(_ date: Date) {
        selectedDate = date
        updateCurrentWeek()
        selectedScheduledOutfit = scheduledOutfits.first {
            calendar.isDate($0.date, inSameDayAs: date)
        }
    }

    func changeWeek(by value: Int) {
        if let newDate = calendar.date(byAdding: .weekOfYear, value: value, to: selectedDate) {
            selectedDate = newDate
            updateCurrentWeek()
        }
    }

    func fetchClothingStats() {
        clothingStats = [
            ClothingStat(id: UUID(), clothingItem: "Blue Jeans", usageCount: 12),
            ClothingStat(id: UUID(), clothingItem: "White T-Shirt", usageCount: 20),
            ClothingStat(id: UUID(), clothingItem: "Black Jacket", usageCount: 5),
            ClothingStat(id: UUID(), clothingItem: "Sneakers", usageCount: 15),
            ClothingStat(id: UUID(), clothingItem: "Cap", usageCount: 8)
        ]
    }

    func fetchScheduledOutfits(completion: @escaping (Result<[ScheduledOutfitResponse], Error>) -> Void) {
        guard let url = URL(string: "https://gate-acidnaya.amvera.io/api/v1/wardrobe-service/calendar/all") else {
            print("❌ Невалидный URL")
            completion(.failure(NSError(domain: "Invalid URL", code: 400)))
            return
        }

        print("🌐 Запрос на \(url)")

        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        if let token = KeychainHelper.get(forKey: "accessToken") {
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
            print("🔐 Токен авторизации добавлен")
        }

        URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                if let error = error {
                    print("❌ Ошибка сети: \(error)")
                    completion(.failure(error))
                    return
                }

                guard let data = data else {
                    print("❌ Нет данных в ответе")
                    completion(.failure(NSError(domain: "No data", code: 500)))
                    return
                }

                print("📦 Ответ от сервера (сырые данные):")
                if let raw = String(data: data, encoding: .utf8) {
                    print(raw)
                }

                do {
                    let decoder = JSONDecoder()

                    // Создаём два форматтера: один для ISO и один короткий
                    let isoFormatter = ISO8601DateFormatter()
                    isoFormatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]

                    let shortFormatter = DateFormatter()
                    shortFormatter.locale = Locale(identifier: "en_US_POSIX")
                    shortFormatter.dateFormat = "yyyy-MM-dd"

                    decoder.dateDecodingStrategy = .custom { decoder in
                        let container = try decoder.singleValueContainer()
                        let dateStr = try container.decode(String.self)

                        if let date = isoFormatter.date(from: dateStr) {
                            return date
                        } else if let short = shortFormatter.date(from: dateStr) {
                            return short
                        } else {
                            throw DecodingError.dataCorruptedError(in: container, debugDescription: "❌ Невалидный формат даты: \(dateStr)")
                        }
                    }

                    let scheduled = try decoder.decode([ScheduledOutfitResponse].self, from: data)
                    print("✅ Успешно загружено \(scheduled.count) запланированных аутфитов")
                    completion(.success(scheduled))
                } catch {
                    print("❌ Ошибка декодирования: \(error)")
                    completion(.failure(error))
                }
            }
        }.resume()
    }



    var totalItems: Int {
        clothingStats.count
    }

    var weeklyUsage: Int {
        clothingStats.reduce(0) { $0 + $1.usageCount }
    }

    var mostPopularItem: String {
        clothingStats.max { $0.usageCount < $1.usageCount }?.clothingItem ?? "Нет данных"
    }

    func addClothingItem(name: String, image: UIImage?) {
        let newItem = ClothingItem(name: name)
        clothingItems.append(newItem)
    }
}
