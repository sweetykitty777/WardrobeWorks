//
//  FollowListViewModel.swift
//  diploma
//
//  Created by Olga on 24.04.2025.
//

import Foundation
import Combine

class FollowListViewModel: ObservableObject {
    @Published var users: [UserPreview] = []
    @Published var isLoading = false
    @Published var errorMessage: String?

    func fetchFollowers() {
        fetch(from: "/api/v1/follow/followers")
    }

    func fetchFollowings() {
        fetch(from: "/api/v1/follow/followings")
    }

    private func fetch(from endpoint: String) {
        guard let url = URL(string: "https://gate-acidnaya.amvera.io\(endpoint)") else { return }

        var request = URLRequest(url: url)
        request.httpMethod = "GET"

        if let token = KeychainHelper.get(forKey: "accessToken") {
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }

        isLoading = true
        URLSession.shared.dataTask(with: request) { data, _, error in
            DispatchQueue.main.async {
                self.isLoading = false
                if let error = error {
                    self.errorMessage = error.localizedDescription
                    return
                }

                guard let data = data else {
                    self.errorMessage = "No data received"
                    return
                }

                do {
                    let users = try JSONDecoder().decode([UserPreview].self, from: data)
                    self.users = users
                } catch {
                    self.errorMessage = "Decode error: \(error.localizedDescription)"
                }
            }
        }.resume()
    }
}
