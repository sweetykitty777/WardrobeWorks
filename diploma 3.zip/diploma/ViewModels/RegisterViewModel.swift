//  RegisterViewModel.swift
//  diploma

import Foundation
import Combine

class RegisterViewModel: ObservableObject {
    @Published var email: String = ""
    @Published var password: String = ""
    @Published var confirmPassword: String = ""
    @Published var username: String = ""
    @Published var errorMessage: String?
    @Published var registrationSuccess: Bool = false

    private var cancellables = Set<AnyCancellable>()

    func register() {
        guard password == confirmPassword else {
            self.errorMessage = "Пароли не совпадают"
            return
        }

        guard let registerURL = URL(string: "https://gate-acidnaya.amvera.io/api/v1/auth/register"),
              let usernameURL = URL(string: "https://gate-acidnaya.amvera.io/api/v1/social-service/users/create")
        else {
            self.errorMessage = "Неверный URL"
            return
        }

        let registerBody = [
            "email": email,
            "password": password
        ]

        var registerRequest = URLRequest(url: registerURL)
        registerRequest.httpMethod = "POST"
        registerRequest.addValue("application/json", forHTTPHeaderField: "Content-Type")

        do {
            registerRequest.httpBody = try JSONSerialization.data(withJSONObject: registerBody, options: [])
        } catch {
            self.errorMessage = "Ошибка при создании запроса"
            return
        }

        URLSession.shared.dataTask(with: registerRequest) { data, response, error in
            guard error == nil else {
                DispatchQueue.main.async {
                    self.errorMessage = "Ошибка регистрации: \(error!.localizedDescription)"
                }
                return
            }

            // Успешная регистрация — теперь устанавливаем ник
            var usernameRequest = URLRequest(url: usernameURL)
            usernameRequest.httpMethod = "POST"
            usernameRequest.addValue("application/json", forHTTPHeaderField: "Content-Type")
            let usernameBody = ["username": self.username]

            do {
                usernameRequest.httpBody = try JSONSerialization.data(withJSONObject: usernameBody, options: [])
            } catch {
                DispatchQueue.main.async {
                    self.errorMessage = "Ошибка при создании запроса ника"
                }
                return
            }

            URLSession.shared.dataTask(with: usernameRequest) { data, response, error in
                DispatchQueue.main.async {
                    if let error = error {
                        self.errorMessage = "Ошибка установки ника: \(error.localizedDescription)"
                    } else {
                        self.registrationSuccess = true
                        print("✅ Регистрация + ник успешно сохранены")
                    }
                }
            }.resume()

        }.resume()
    }
    
   /* @Published var isNicknameMissing: Bool = false
    func checkNickname() {
        guard let url = URL(string: "https://gate-acidnaya.amvera.io/api/v1/social-service/users/self") else { return }

        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue("Bearer \(accessToken)", forHTTPHeaderField: "Authorization")

        URLSession.shared.dataTask(with: request) { data, _, error in
            guard let data = data else { return }

            do {
                let user = try JSONDecoder().decode(UserProfile.self, from: data)
                DispatchQueue.main.async {
                    self.isNicknameMissing = user.username.isEmpty
                }
            } catch {
                print("❌ Ошибка парсинга профиля: \(error)")
            }
        }.resume()
    }*/

}
