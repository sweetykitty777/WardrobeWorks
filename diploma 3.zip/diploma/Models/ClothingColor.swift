//
//  ClothingColor.swift
//  diploma
//
//  Created by Olga on 22.04.2025.
//

import Foundation
struct ClothingColor: Codable, Identifiable, NamedItem {
    let id: Int
    let name: String
    let colourcode: String
}
