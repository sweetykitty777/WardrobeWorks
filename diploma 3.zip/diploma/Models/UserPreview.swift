//
//  UserPreview.swift
//  diploma
//
//  Created by Olga on 24.04.2025.
//

import Foundation
struct UserPreview: Identifiable, Codable {
    let id: Int
    let username: String
    let bio: String
    let avatar: String
}
