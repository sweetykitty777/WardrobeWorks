//
//  LoginResponse.swift
//  diploma
//
//  Created by Olga on 13.04.2025.
//

import Foundation
struct LoginResponse: Codable {
    let token: String
}
