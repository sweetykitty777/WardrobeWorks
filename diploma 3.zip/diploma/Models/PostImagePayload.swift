//
//  PostImagePayload.swift
//  diploma
//
//  Created by Olga on 24.04.2025.
//

import Foundation
struct PostImagePayload: Codable {
    let imagePath: String
    let position: Int
    let outfitId: Int
}
