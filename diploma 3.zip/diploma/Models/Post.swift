//
//  Post.swift
//  diploma
//
//  Created by Olga on 24.04.2025.
//

import Foundation

struct Post: Identifiable, Decodable {
    var id: Int
    var user: Int // ID пользователя, который сделал пост
    var createdAt: String // Время создания поста (в ISO формате)
    var text: String // Текст поста
    var images: [String] // Список URL изображений
    var likes: Int // Количество лайков

    // Инициализатор по умолчанию, который автоматически генерируется для Decodable
}
