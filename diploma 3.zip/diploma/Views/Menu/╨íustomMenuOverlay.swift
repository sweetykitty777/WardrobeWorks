import SwiftUI

struct CustomMenuOverlay: View {
    @Binding var showingMenu: Bool
    @Binding var showingAddItemSheet: Bool
    @Binding var showingAddOutfitSheet: Bool
    @Binding var showingAddPostSheet: Bool

    var body: some View {
        VStack(spacing: 16) {
            Capsule()
                .fill(Color.gray.opacity(0.2))
                .frame(width: 40, height: 5)
                .padding(.top, 8)

            Button(action: {
                showingMenu = false
                showingAddItemSheet = true
            }) {
                HStack {
                    Text("Добавить вещь")
                        .font(.headline)
                        .foregroundColor(.black)
                    Spacer()
                    Image(systemName: "chevron.right")
                        .foregroundColor(.gray)
                }
                .padding()
                .background(Color.white)
                .cornerRadius(10)
                .shadow(radius: 1)
            }
            .padding(.horizontal, 20)

            Button(action: {
                showingMenu = false
                showingAddOutfitSheet = true
            }) {
                HStack {
                    Text("Создать аутфит")
                        .font(.headline)
                        .foregroundColor(.black)
                    Spacer()
                    Image(systemName: "chevron.right")
                        .foregroundColor(.gray)
                }
                .padding()
                .background(Color.white)
                .cornerRadius(10)
                .shadow(radius: 1)
            }
            .padding(.horizontal, 20)

            Button(action: {
                showingMenu = false
                showingAddPostSheet = true
            }) {
                HStack {
                    Text("Создать пост")
                        .font(.headline)
                        .foregroundColor(.black)
                    Spacer()
                    Image(systemName: "chevron.right")
                        .foregroundColor(.gray)
                }
                .padding()
                .background(Color.white)
                .cornerRadius(10)
                .shadow(radius: 1)
            }
            .padding(.horizontal, 20)

            Spacer()
        }
        .padding(.top, 16)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color(UIColor.systemGroupedBackground))
        .cornerRadius(20)
        .edgesIgnoringSafeArea(.bottom)
    }
}
