import SwiftUI

struct OutfitsView: View {
    @ObservedObject var viewModel: OutfitViewModel
    var wardrobeId: Int

    private let columns = [
        GridItem(.flexible(), spacing: 12),
        GridItem(.flexible(), spacing: 12)
    ]

    var body: some View {
        NavigationView {
            ScrollView {
                LazyVGrid(columns: columns, spacing: 16) {
                    ForEach(viewModel.outfits) { outfit in
                        NavigationLink(destination: OutfitDetailView(outfit: outfit)) {
                            OutfitCard(outfit: outfit)
                        }
                        .buttonStyle(PlainButtonStyle()) // чтобы убрать синие эффекты ссылки
                    }
                }
                .padding()
            }
            .navigationBarHidden(true)
            .onAppear {
                viewModel.fetchOutfits(for: wardrobeId)
            }
        }
    }
}
