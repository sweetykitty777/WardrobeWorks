import SwiftUI

struct OutfitDetailView: View {
    let outfit: OutfitResponse
    @State private var scheduledOutfits: [ScheduledOutfit] = []
    @State private var showShareSheet = false
    @State private var imageToShare: UIImage?

   /* var scheduledDates: [Date] {
        scheduledOutfits
            .filter { $0.outfit.id == outfit.id }
            .map { $0.date }
            .sorted()
    }*/

    var body: some View {
        ScrollView {
            VStack(spacing: 20) {

                // Изображение аутфита
                if let imagePath = outfit.imagePath {
                    RemoteImageView(urlString: imagePath)
                        .frame(height: 220)
                        .clipShape(RoundedRectangle(cornerRadius: 20))
                        .padding(.horizontal)
                        .padding(.top)
                        .background(Color.white)
                        .cornerRadius(20)
                        .shadow(color: Color.black.opacity(0.05), radius: 8, x: 0, y: 4)
                        .onTapGesture {
                            shareImage(from: imagePath)
                        }
                }

                // Заголовок
                Text("Состав аутфита")
                    .font(.headline)
                    .padding(.horizontal)

                // Вещи в аутфите (опционально)

                // Даты планирования
                VStack(alignment: .leading, spacing: 10) {
                    HStack {
                        Text("Запланирован на:")
                            .font(.headline)
                        Spacer()
                        NavigationLink(destination: WeeklyCalendarView()) {
                            Image(systemName: "plus.circle.fill")
                                .font(.title3)
                                .foregroundColor(.blue)
                        }
                    }
                    .padding(.horizontal)

                  /*  if !scheduledDates.isEmpty {
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 8) {
                                ForEach(scheduledDates, id: \.self) { date in
                                    Text(shortDate(date))
                                        .font(.subheadline)
                                        .foregroundColor(.white)
                                        .padding(.horizontal, 12)
                                        .padding(.vertical, 6)
                                        .background(Color.blue)
                                        .cornerRadius(12)
                                        .shadow(radius: 1)
                                }
                            }
                            .padding(.horizontal)
                        }
                    }*/
                }
                .padding(.top)

                Spacer(minLength: 20)
            }
        }
        .background(Color(.systemGroupedBackground).ignoresSafeArea())
        .onAppear {
            scheduledOutfits = MockData.scheduledOutfits
        }
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                if imageToShare != nil {
                    Button(action: {
                        showShareSheet = true
                    }) {
                        Image(systemName: "square.and.arrow.up")
                            .foregroundColor(.blue)
                    }
                }
            }
        }
        .sheet(isPresented: $showShareSheet) {
            if let image = imageToShare {
                ActivityView(activityItems: [image])
            }
        }
    }

    private func shortDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "dd MMM"
        return formatter.string(from: date)
    }

    private func shareImage(from urlString: String) {
        guard let url = URL(string: urlString) else { return }

        URLSession.shared.dataTask(with: url) { data, _, _ in
            if let data = data, let image = UIImage(data: data) {
                DispatchQueue.main.async {
                    imageToShare = image
                    showShareSheet = true
                }
            }
        }.resume()
    }
}

struct ActivityView: UIViewControllerRepresentable {
    let activityItems: [Any]
    let applicationActivities: [UIActivity]? = nil

    func makeUIViewController(context: Context) -> UIActivityViewController {
        return UIActivityViewController(activityItems: activityItems, applicationActivities: applicationActivities)
    }

    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {
        // Ничего обновлять не нужно
    }
}
