import SwiftUI

struct ClothesView: View {
    @Binding var selectedItems: [OutfitItem]
    var wardrobeId: Int

    @StateObject private var viewModel = ClothesViewModel()

    private var groupedClothes: [String: [ClothItem]] {
        Dictionary(grouping: viewModel.clothes, by: { $0.category })
    }

    var body: some View {
        NavigationView {
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 20) {
                    ForEach(groupedClothes.keys.sorted(), id: \.self) { category in
                        VStack(alignment: .leading, spacing: 8) {
                            Text(category)
                                .font(.system(size: 22, weight: .semibold))
                                .foregroundColor(.primary)
                                .padding(.horizontal, 20)
                                .padding(.top, 24)

                            ScrollView(.horizontal, showsIndicators: false) {
                                LazyHStack(spacing: 12) {
                                    ForEach(groupedClothes[category] ?? []) { item in
                                        ClothItemView(item: item, selectedItems: $selectedItems)
                                    }
                                }
                                .padding(.horizontal)
                                .padding(.bottom, 10)
                            }
                        }
                    }
                }
            }
            .background(Color(.systemGroupedBackground))
            .navigationBarHidden(true)
            .onAppear {
                viewModel.fetchClothes(for: wardrobeId)
            }
        }
    }
}
