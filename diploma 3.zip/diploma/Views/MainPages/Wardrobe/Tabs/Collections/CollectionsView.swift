import SwiftUI

struct CollectionsView: View {
    @State private var collections: [LookbookResponse] = []
    @State private var showingNewCollectionSheet = false
    @State private var editingCollectionID: Int?
    
    // Use the passed-in parameter for selectedWardrobeId
    var wardrobeId: Int

    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                ScrollView {
                    LazyVStack(spacing: 12) {
                        ForEach(collections, id: \.id) { collection in
                            LookbookListItemView(
                                title: collection.name,
                                subtitle: collection.description,
                                onEdit: {
                                    editingCollectionID = collection.id
                                },
                                isEditing: editingCollectionID == collection.id,
                                onCommit: { newName in
                                    // Handle the update logic for collection name
                                    print("Новое имя: \(newName)")
                                    editingCollectionID = nil
                                }
                            )
                            .padding(.horizontal)
                        }
                    }
                    .padding(.top)
                }

                Button(action: {
                    showingNewCollectionSheet = true
                }) {
                    HStack {
                        Image(systemName: "plus.circle.fill")
                        Text("Добавить новый лукбук")
                    }
                    .font(.headline)
                    .foregroundColor(.blue)
                    .padding()
                }
            }
            .navigationBarHidden(true)
            .onAppear {
                // Fetch the lookbooks based on the selected wardrobeId
                fetchLookbooks(for: wardrobeId)
            }
        }
        .sheet(isPresented: $showingNewCollectionSheet) {
            NewCollectionView(collections: .constant([]), isPresented: $showingNewCollectionSheet)
        }
    }

    // Fetch Lookbooks for a specific wardrobe ID
    private func fetchLookbooks(for wardrobeId: Int) {

        LookbookService.shared.fetchLookbooks(for: wardrobeId) { result in
            switch result {
            case .success(let fetched):
                collections = fetched // Update collections with the fetched data
            case .failure(let error):
                print("❌ Ошибка загрузки лукбуков: \(error)")
            }
        }
    }
}
