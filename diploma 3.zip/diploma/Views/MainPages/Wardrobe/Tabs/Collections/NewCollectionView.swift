import SwiftUI

struct NewCollectionView: View {
    @Binding var collections: [CreateCollection]
    @Binding var isPresented: Bool

    @State private var collectionName: String = ""
    @State private var selectedWardrobeId: Int?
    @StateObject private var wardrobeViewModel = WardrobeViewModel()
    @State private var isCreating = false

    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                TextField("Введите название лукбука", text: $collectionName)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding(.horizontal)

                // Меню выбора гардероба
                Menu {
                    ForEach(wardrobeViewModel.wardrobes, id: \.id) { wardrobe in
                        Button(wardrobe.name) {
                            selectedWardrobeId = wardrobe.id
                        }
                    }
                } label: {
                    HStack {
                        Text(selectedWardrobeName)
                            .foregroundColor(.primary)
                        Spacer()
                        Image(systemName: "chevron.down")
                            .foregroundColor(.gray)
                    }
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.white)
                    .cornerRadius(10)
                    .shadow(radius: 1)
                    .padding(.horizontal)
                }

                Button(isCreating ? "Создание..." : "Создать") {
                    createLookbook()
                }
                .disabled(isCreating || collectionName.isEmpty || selectedWardrobeId == nil)
                .font(.headline)
                .foregroundColor(.white)
                .padding()
                .frame(maxWidth: .infinity)
                .background(Color.blue)
                .cornerRadius(10)
                .padding(.horizontal)

                Spacer()
            }
            .navigationTitle("Новый лукбук")
            .navigationBarItems(trailing: Button("Отмена") {
                isPresented = false
            })
            .onAppear {
                wardrobeViewModel.fetchWardrobes()
            }
        }
    }

    private var selectedWardrobeName: String {
        if let id = selectedWardrobeId,
           let wardrobe = wardrobeViewModel.wardrobes.first(where: { $0.id == id }) {
            return wardrobe.name
        } else {
            return "Выбрать гардероб"
        }
    }

    private func createLookbook() {
        guard let wardrobeId = selectedWardrobeId else { return }

        isCreating = true

        LookbookService.shared.createLookbook(
            wardrobeId: wardrobeId,
            name: collectionName,
            description: ""
        ) { result in
            DispatchQueue.main.async {
                isCreating = false
                switch result {
                case .success:
                    let newCollection = CreateCollection(
                        name: collectionName,
                        wardrobeId: wardrobeId,
                        outfits: []
                    )
                    collections.append(newCollection)
                    isPresented = false
                case .failure(let error):
                    print("❌ Ошибка создания лукбука: \(error.localizedDescription)")
                }
            }
        }
    }
}

