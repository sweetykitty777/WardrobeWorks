import SwiftUI

struct InspirationView: View {
    @StateObject private var viewModel = InspirationViewModel()
    @StateObject private var outfitViewModel = OutfitViewModel() // ✅ Добавили

    @State private var showingCommentSheet: Bool = false
    @State private var selectedPostIndex: Int?
    @State private var showingCreatePostSheet: Bool = false

    var body: some View {
        NavigationView {
            VStack(spacing: 12) {
                HStack {
                    // Убираем сегментированный выбор источников (фильтрацию по подпискам)
                    Text("Все посты")
                        .font(.title2)
                    Spacer()
                    Button(action: {
                        showingCreatePostSheet = true
                    }) {
                        Image(systemName: "plus")
                            .font(.title2)
                            .padding(8)
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .clipShape(Circle())
                            .shadow(radius: 2)
                    }
                }
                .padding(.horizontal)

                ScrollView {
                    LazyVStack(spacing: 20) {
                        // Убираем фильтрацию по подпискам, просто отображаем все посты
                        ForEach(viewModel.posts.indices, id: \.self) { index in
                            PostView(post: $viewModel.posts[index])
                                .onTapGesture {
                                    selectedPostIndex = index
                                    showingCommentSheet = true
                                }
                        }
                    }
                    .padding()
                }
            }
            .navigationTitle("Лента публикаций")
        }
        .sheet(isPresented: $showingCommentSheet) {
            if let index = selectedPostIndex {
                CommentsView(post: $viewModel.posts[index])
            }
        }
        .sheet(isPresented: $showingCreatePostSheet) {
            CreatePostView(posts: $viewModel.posts, outfitViewModel: outfitViewModel) // ✅ Передаём VM
        }
    }
}
