import SwiftUI

struct PostView: View {
    @Binding var post: Post

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            // MARK: - Post Image
            if let imageUrl = post.images.first, let url = URL(string: imageUrl) {
                RemoteImageView(
                    urlString: imageUrl,
                    cornerRadius: 16,
                    width: UIScreen.main.bounds.width - 32,
                    height: UIScreen.main.bounds.width * 0.75
                )
                .clipped()
                .cornerRadius(16)
                .overlay(
                    RoundedRectangle(cornerRadius: 16)
                        .stroke(Color(.systemGray5), lineWidth: 1)
                )
                .shadow(color: Color.black.opacity(0.05), radius: 8, x: 0, y: 4)
            } else {
                Image(systemName: "photo")
                    .resizable()
                    .scaledToFit()
                    .frame(width: UIScreen.main.bounds.width - 32, height: UIScreen.main.bounds.width * 0.75)
                    .foregroundColor(.gray.opacity(0.5))
                    .background(Color(.systemGray6))
                    .cornerRadius(16)
                    .overlay(
                        RoundedRectangle(cornerRadius: 16)
                            .stroke(Color.gray.opacity(0.2), lineWidth: 1)
                    )
            }

            // MARK: - Caption
            if let caption = post.text {
                Text(caption)
                    .font(.system(size: 16))
                    .foregroundColor(.primary)
                    .multilineTextAlignment(.leading)
                    .lineLimit(nil) // Allow the caption to use multiple lines if necessary
                    .padding([.leading, .trailing], 16) // Keep consistent padding for caption
            }

            // MARK: - Actions
            HStack {
                Button(action: {
                    post.likes += 1
                }) {
                    Label("4", systemImage: "heart.fill")
                        .foregroundColor(.red)
                }

                Spacer()

                Button(action: {
                    // Add comment logic here
                }) {
                    Label("3", systemImage: "message.fill")
                        .foregroundColor(.blue)
                }
            }
            .font(.subheadline)
            .padding([.leading, .trailing], 16)  // Added horizontal padding to match the other elements
            .padding(.bottom, 12)
        }
        .background(Color.white)
        .cornerRadius(20)
        .shadow(color: Color.black.opacity(0.05), radius: 10, x: 0, y: 4)
        .padding([.horizontal, .top], 16)
    }
}
