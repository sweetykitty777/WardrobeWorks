import SwiftUI

struct UserProfileView: View {
    @EnvironmentObject var authViewModel: AuthViewModel
    @StateObject private var viewModel = UserProfileViewModel()

    @State private var isEditing = false
    @State private var showFollowers = false
    @State private var showFollowings = false

    @StateObject private var followersVM = FollowListViewModel()
    @StateObject private var followingsVM = FollowListViewModel()

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 16) {
                    // Avatar and user info
                    VStack(spacing: 8) {
                        if let avatarURL = viewModel.user.avatar {
                            RemoteImageView(urlString: avatarURL, cornerRadius: 40, width: 80, height: 80)
                        } else {
                            Image(systemName: "person.crop.circle")
                                .resizable()
                                .frame(width: 80, height: 80)
                                .foregroundColor(.gray)
                        }

                        Text("@\(viewModel.user.username)")
                            .font(.title2)
                            .fontWeight(.semibold)

                        if let bio = viewModel.user.bio {
                            Text(bio)
                                .font(.body)
                                .foregroundColor(.secondary)
                        }
                    }
                    .padding(.top)

                    // Followers/Followings
                    HStack(spacing: 40) {
                        VStack {
                            Text("\(followersVM.users.count)")
                                .font(.title3)
                                .fontWeight(.semibold)
                            Text("Подписчики")
                                .font(.caption)
                        }
                        .onTapGesture {
                            followersVM.fetchFollowers()
                            showFollowers = true
                        }

                        VStack {
                            Text("\(followingsVM.users.count)")
                                .font(.title3)
                                .fontWeight(.semibold)
                            Text("Подписки")
                                .font(.caption)
                        }
                        .onTapGesture {
                            followingsVM.fetchFollowings()
                            showFollowings = true
                        }
                    }

                    Divider()

                    // Public Posts ScrollView
                    VStack(alignment: .leading) {
                        Text("Публикации")
                            .font(.headline)
                            .padding(.leading)

                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 16) {
                                ForEach(viewModel.posts, id: \.id) { post in
                                    PostView(post: $viewModel.posts.first { $0.id == post.id }!)
                                }
                            }
                            .padding(.leading)
                        }
                    }
                    .padding(.top)

                    // Public Items ScrollView
                    VStack(alignment: .leading) {
                        Text("Публичные вещи")
                            .font(.headline)
                            .padding(.leading)

                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 16) {
                                ForEach(viewModel.publicItems, id: \.id) { item in
                                    ClothItemProfileView(item: item)
                                }
                            }
                            .padding(.leading)
                        }
                    }
                    .padding(.top)

                    // Public Outfits ScrollView
                    VStack(alignment: .leading) {
                        Text("Публичные аутфиты")
                            .font(.headline)
                            .padding(.leading)

                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 16) {
                                ForEach(viewModel.publicOutfits, id: \.id) { outfit in
                                    OutfitCard(outfit: outfit)
                                }
                            }
                            .padding(.leading)
                        }
                    }
                    .padding(.top)
                }
                .padding(.horizontal)
            }
            .navigationTitle("Профиль")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    HStack(spacing: 16) {
                        Button {
                            isEditing = true
                        } label: {
                            Image(systemName: "pencil")
                        }

                        Button {
                            authViewModel.logout()
                        } label: {
                            Image(systemName: "rectangle.portrait.and.arrow.right")
                                .foregroundColor(.red)
                        }
                        .accessibilityLabel("Выйти")
                    }
                }
            }
            .onAppear {
                viewModel.loadUserProfile()
            }
            .sheet(isPresented: $isEditing) {
                EditProfileView(viewModel: viewModel)
            }
            .sheet(isPresented: $showFollowers) {
                NavigationView {
                    FollowListView(viewModel: followersVM, title: "Подписчики")
                }
            }
            .sheet(isPresented: $showFollowings) {
                NavigationView {
                    FollowListView(viewModel: followingsVM, title: "Подписки")
                }
            }
        }
    }
}
