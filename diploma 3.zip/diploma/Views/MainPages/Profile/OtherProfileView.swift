//
//  OtherProfileView.swift
//  diploma
//
//  Created by Olga on 23.04.2025.
//

import Foundation
import SwiftUI

struct OtherUserProfileView: View {
    let username: String

    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                Image(systemName: "person.crop.circle")
                    .resizable()
                    .frame(width: 80, height: 80)
                    .foregroundColor(.gray)
                Text("@\(username)")
                    .font(.title2)
                    .fontWeight(.semibold)

                Text("Это публичный профиль пользователя \(username).")
                    .font(.body)
                    .foregroundColor(.secondary)
                    .padding()

                Divider()

                Text("Публикации")
                    .font(.headline)

                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 8) {
                    ForEach(0..<6, id: \.self) { _ in
                        Rectangle()
                            .fill(Color.gray.opacity(0.3))
                            .aspectRatio(1, contentMode: .fit)
                    }
                }
            }
            .padding()
        }
        .navigationTitle("@\(username)")
        .navigationBarTitleDisplayMode(.inline)
    }
}
