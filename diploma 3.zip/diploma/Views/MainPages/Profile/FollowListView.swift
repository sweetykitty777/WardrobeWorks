//
//  FollowListView.swift
//  diploma
//
//  Created by Olga on 24.04.2025.
//

import Foundation
import SwiftUI

struct FollowListView: View {
    @ObservedObject var viewModel: FollowListViewModel
    var title: String

    var body: some View {
        List(viewModel.users) { user in
            HStack {
                AsyncImage(url: URL(string: user.avatar)) { image in
                    image.resizable()
                } placeholder: {
                    Color.gray
                }
                .frame(width: 40, height: 40)
                .clipShape(Circle())

                VStack(alignment: .leading) {
                    Text(user.username).font(.headline)
                    Text(user.bio).font(.caption).foregroundColor(.gray)
                }
            }
        }
        .navigationTitle(title)
        .onAppear {
            // fetch заранее сделан в родителе
        }
    }
}
