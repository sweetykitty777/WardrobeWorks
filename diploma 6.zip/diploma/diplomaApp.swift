//
//  diplomaApp.swift
//  diploma
//
//  Created by Olga on 05.01.2025.
//

import SwiftUI

@main
struct diplomaApp: App {
    var body: some Scene {
        WindowGroup {
            AppRootView()
         //    WeeklyCalendarView()
        }
    }
}
