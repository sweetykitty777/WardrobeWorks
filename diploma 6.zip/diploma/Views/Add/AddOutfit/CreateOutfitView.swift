import SwiftUI

struct CreateOutfitView: View {
    @StateObject private var viewModel = CreateOutfitViewModel()
    @Environment(\.presentationMode) private var presentationMode

    var body: some View {
        NavigationView {
            VStack(spacing: 16) {
                wardrobeMenu

                canvasView
                    .frame(height: 400)
                    .background(Color.white)
                    .cornerRadius(12)
                    .shadow(radius: 1)
                    .padding(.horizontal)

                actionButtons

                Spacer()
            }
            .padding(.top)
            .background(Color(.systemGroupedBackground).ignoresSafeArea())
            .navigationTitle("Создать аутфит")
            .sheet(isPresented: $viewModel.showingWardrobe) {
                if let id = viewModel.selectedWardrobeId {
                    WardrobeSelectionView(
                        selectedItems: $viewModel.placedItems,
                        wardrobeId: id,
                        imageURLs: $viewModel.imageURLsByClothId
                    )
                }
            }
            .onAppear {
                viewModel.fetchWardrobes()
            }
            .overlay(
                Group {
                    if viewModel.showToast {
                        ToastView(message: viewModel.toastMessage)
                            .transition(.opacity)
                            .padding()
                    }
                }
            )
        }
    }

    private var wardrobeMenu: some View {
        Menu {
            ForEach(viewModel.wardrobes, id: \..id) { wardrobe in
                Button(wardrobe.name) {
                    viewModel.selectWardrobe(wardrobe)
                }
            }
        } label: {
            HStack {
                Text(viewModel.selectedWardrobeName)
                    .foregroundColor(viewModel.selectedWardrobeId == nil ? .gray : .primary)
                Spacer()
                Image(systemName: "chevron.down")
                    .foregroundColor(.gray)
            }
            .padding()
            .background(Color.white)
            .cornerRadius(12)
            .overlay(
                RoundedRectangle(cornerRadius: 12)
                    .stroke(Color.gray.opacity(0.2), lineWidth: 1)
            )
            .padding(.horizontal)
        }
    }

    private var canvasView: some View {
        GeometryReader { geometry in
            ZStack {
                Color.clear

                ForEach($viewModel.placedItems, id: \..clothId) { $item in
                    if let imageURL = viewModel.imageURLsByClothId[item.clothId] {
                        DraggableItem(
                            item: $item,
                            imageURL: imageURL,
                            canvasSize: geometry.size,
                            onDelete: {
                                viewModel.removeItem(item)
                            }
                        )
                    }
                }
            }
        }
    }

    private var actionButtons: some View {
        VStack(spacing: 12) {
            Button(action: {
                if viewModel.selectedWardrobeId != nil {
                    viewModel.showingWardrobe = true
                }
            }) {
                Label("Добавить вещи", systemImage: "plus.circle.fill")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.white)
                    .cornerRadius(12)
                    .shadow(radius: 1)
                    .padding(.horizontal)
            }

            Button(action: {
                viewModel.saveOutfit {
                    presentationMode.wrappedValue.dismiss()
                }
            }) {
                Text(viewModel.isSaving ? "Сохранение..." : "Сохранить аутфит")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(viewModel.isSaving ? Color.gray.opacity(0.5) : Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(12)
                    .padding(.horizontal)
            }
            .disabled(viewModel.isSaving)
        }
    }
}
