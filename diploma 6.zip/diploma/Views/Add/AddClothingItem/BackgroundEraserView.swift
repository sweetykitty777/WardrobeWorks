import SwiftUI

struct BackgroundEraserView: View {
    @StateObject private var viewModel: BackgroundEraserViewModel
    let onFinish: (UIImage) -> Void

    @Environment(\.dismiss) private var dismiss

    init(inputImage: UIImage, onFinish: @escaping (UIImage) -> Void) {
        _viewModel = StateObject(wrappedValue: BackgroundEraserViewModel(image: inputImage))
        self.onFinish = onFinish
    }

    var body: some View {
        VStack(spacing: 0) {
            GeometryReader { geometry in
                let imageSize = viewModel.inputImage.size
                let containerSize = geometry.size
                let fittedSize = viewModel.aspectFitSize(for: imageSize, in: containerSize)

                ZStack {
                    Color.white

                    Image(uiImage: viewModel.inputImage)
                        .resizable()
                        .frame(width: fittedSize.width, height: fittedSize.height)
                        .position(x: containerSize.width / 2, y: containerSize.height / 2)
                        .compositingGroup()
                        .overlay(drawingOverlay)
                        .gesture(
                            DragGesture(minimumDistance: 0)
                                .onChanged { value in
                                    viewModel.addErasePoint(at: value.location)
                                }
                        )
                }
            }
            .background(Color.white)
            .frame(maxHeight: .infinity)

            Divider()

            controls
        }
        .ignoresSafeArea()
    }

    private var drawingOverlay: some View {
        ZStack {
            ForEach(viewModel.erasePoints) { point in
                Circle()
                    .fill(Color.white)
                    .frame(width: point.size, height: point.size)
                    .position(point.point)
            }
        }
    }

    private var controls: some View {
        VStack(spacing: 14) {
            // Настройка размера кисти
            VStack(alignment: .leading, spacing: 4) {
                Text("Размер кисти: \(Int(viewModel.brushSize))")
                    .font(.caption)
                    .foregroundColor(.gray)
                Slider(value: $viewModel.brushSize, in: 10...100)
                    .accentColor(.blue)
            }
            .padding(.horizontal)

            // Автообрезка
            if viewModel.isAutoCropping {
                ProgressView(value: viewModel.progress)
                    .progressViewStyle(LinearProgressViewStyle())
                    .padding(.horizontal)
            } else {
                Button(action: {
                    viewModel.startAutoCrop {}
                }) {
                    Label("Автообрезка", systemImage: "scissors")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.gray.opacity(0.2))
                        .cornerRadius(10)
                }
                .padding(.horizontal)
            }

            // Очистить
            Button(action: viewModel.clearAll) {
                Label("Очистить всё", systemImage: "trash")
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.red.opacity(0.15))
                    .foregroundColor(.red)
                    .cornerRadius(10)
            }
            .padding(.horizontal)

            // Готово
            Button("Готово") {
                let image = viewModel.renderErasedImage(screenWidth: UIScreen.main.bounds.width)
                onFinish(image)
                dismiss()
            }
            .frame(maxWidth: .infinity)
            .padding()
            .background(Color.blue)
            .foregroundColor(.white)
            .cornerRadius(12)
            .padding(.horizontal)
        }
        .padding(.vertical)
        .background(Color.white)
    }
}
