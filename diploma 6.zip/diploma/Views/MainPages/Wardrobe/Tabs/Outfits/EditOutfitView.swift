import SwiftUI

struct EditOutfitView: View {
    let outfitId: Int

    @State private var clothes: [ClothItem] = []
    @State private var placedItems: [PlacedClothingItem] = []
    @State private var imageURLsByClothId: [Int: String] = [:]
    @State private var isLoading = true

    var body: some View {
        VStack {
            if isLoading {
                ProgressView("Загрузка...")
                    .padding()
            } else {
                // Холст встроенный
                GeometryReader { geometry in
                    ZStack {
                        RoundedRectangle(cornerRadius: 16)
                            .fill(Color.gray.opacity(0.1))

                        ForEach($placedItems) { $item in
                            if let url = imageURLsByClothId[item.clothId] {
                                DraggableItem(
                                    item: $item,
                                    imageURL: url,
                                    canvasSize: geometry.size,
                                    onDelete: {
                                        placedItems.removeAll { $0.id == item.id }
                                    }
                                )
                            }
                        }
                    }
                }
                .frame(height: 400)
                .padding()

                // Список одежды без Card
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 16) {
                        ForEach(clothes) { item in
                            VStack(spacing: 4) {
                                RemoteImageView(
                                    urlString: item.imagePath,
                                    cornerRadius: 8,
                                    width: 80,
                                    height: 80
                                )
                                Text(item.typeName ?? "Без категории")
                                    .font(.caption)
                                    .foregroundColor(.primary)
                                    .lineLimit(1)
                                Text(item.brandName ?? "")
                                    .font(.caption2)
                                    .foregroundColor(.gray)
                                    .lineLimit(1)
                            }
                            .frame(width: 90)
                            .onTapGesture {
                                addToCanvas(item: item)
                            }
                        }
                    }
                    .padding(.horizontal)
                }

                Spacer()

                Button("Сохранить") {
                    print("💾 Сохраняем:")
                    for item in placedItems {
                        print("• clothId \(item.clothId): x=\(Int(item.x)), y=\(Int(item.y)), scale=\(String(format: "%.2f", item.scale)), rotation=\(Int(item.rotation)), zIndex=\(item.zIndex)")
                    }
                }
                .frame(maxWidth: .infinity)
                .padding()
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(12)
                .padding()
            }
        }
        .navigationTitle("Редактировать аутфит")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear(perform: loadMockData)
    }

    // Мок-данные
    private func loadMockData() {
        isLoading = true

        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            let mockClothes: [ClothItem] = [
                ClothItem(id: 1, createdAt: nil, description: "Повседневная футболка", imagePath: "https://via.placeholder.com/80/FF5733", price: 1200, numberOfWear: 5, wardrobeId: 1, typeName: "Футболка", colourName: "Красный", seasonName: "Лето", brandName: "Zara"),
                ClothItem(id: 2, createdAt: nil, description: "Синие джинсы", imagePath: "https://via.placeholder.com/80/33C3FF", price: 2500, numberOfWear: 10, wardrobeId: 1, typeName: "Джинсы", colourName: "Синий", seasonName: "Круглогодично", brandName: "Levi’s"),
                ClothItem(id: 3, createdAt: nil, description: "Зелёная куртка", imagePath: "https://via.placeholder.com/80/85FF33", price: 4500, numberOfWear: 2, wardrobeId: 1, typeName: "Куртка", colourName: "Зелёный", seasonName: "Весна", brandName: "Nike")
            ]
            self.clothes = mockClothes
            self.imageURLsByClothId = Dictionary(uniqueKeysWithValues: mockClothes.map { ($0.id, $0.imagePath) })

            self.placedItems = [
                PlacedClothingItem(clothId: 1, x: 100, y: 100, rotation: 0, scale: 1.0, zIndex: 0),
                PlacedClothingItem(clothId: 2, x: 200, y: 200, rotation: 0, scale: 1.0, zIndex: 1)
            ]

            self.isLoading = false
        }
    }

    private func addToCanvas(item: ClothItem) {
        let newItem = PlacedClothingItem(
            clothId: item.id,
            x: 150,
            y: 150,
            rotation: 0,
            scale: 1.0,
            zIndex: (placedItems.map { $0.zIndex }.max() ?? 0) + 1
        )
        placedItems.append(newItem)
    }
}
