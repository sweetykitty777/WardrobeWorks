//
//  UserCalendar.swift
//  diploma
//
//  Created by Olga on 27.04.2025.
//

import Foundation

struct UserCalendar: Codable {
    let id: Int
    let userId: Int
    let isPrivate: Bool
}
