//
//  ScheduleOutfitRequest.swift
//  diploma
//
//  Created by Olga on 23.04.2025.
//

import Foundation
struct ScheduleOutfitRequest: Codable {
    let outfitId: Int
    let date: String
}
