//
//  BackgroundRemovalService.swift
//  diploma
//
//  Created by Olga on 03.05.2025.
//

import Foundation
import UIKit

protocol BackgroundRemovalService {
    func removeBackground(from imageData: Data, completion: @escaping (Result<UIImage, Error>) -> Void)
}
