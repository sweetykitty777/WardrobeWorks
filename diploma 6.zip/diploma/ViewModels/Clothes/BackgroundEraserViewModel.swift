//
//  BackgroundEraserViewModel.swift
//  diploma
//
//  Created by Olga on 02.05.2025.
//

import SwiftUI
import Foundation

class BackgroundEraserViewModel: ObservableObject {
    // Входное изображение и стираемые точки
    @Published var inputImage: UIImage
    @Published var erasePoints: [ErasePoint] = []

    // Настройки и состояние
    @Published var brushSize: CGFloat = 40
    @Published var isAutoCropping = false
    @Published var progress: CGFloat = 0.0

    private let originalImage: UIImage
    private let removalService: BackgroundRemovalService

    // MARK: - Инициализация
    init(image: UIImage, removalService: BackgroundRemovalService = NetworkBackgroundRemovalService()) {
        self.inputImage = image
        self.originalImage = image
        self.removalService = removalService
    }

    // MARK: - Ручное стирание
    func addErasePoint(at location: CGPoint) {
        erasePoints.append(ErasePoint(point: location, size: brushSize))
    }

    func clearAll() {
        erasePoints.removeAll()
    }

    func resetToOriginal() {
        inputImage = originalImage
        erasePoints.removeAll()
    }

    func undoLast() {
        guard !erasePoints.isEmpty else { return }
        erasePoints.removeLast()
    }

    // MARK: - Автообрезка
    func startAutoCrop(completion: @escaping () -> Void) {
        guard let pngData = inputImage.pngData() else { return }

        isAutoCropping = true
        progress = 0.1

        removalService.removeBackground(from: pngData) { [weak self] result in
            DispatchQueue.main.async {
                self?.isAutoCropping = false
                switch result {
                case .success(let newImg):
                    self?.inputImage = newImg
                    self?.erasePoints.removeAll()
                case .failure(let error):
                    print("❌ Ошибка удаления фона:", error.localizedDescription)
                }
                completion()
            }
        }
    }

    // MARK: - Генерация изображения со стёртым фоном
    func renderErasedImage(screenWidth: CGFloat) -> UIImage {
        let renderer = UIGraphicsImageRenderer(size: inputImage.size)
        return renderer.image { ctx in
            inputImage.draw(in: CGRect(origin: .zero, size: inputImage.size))
            ctx.cgContext.setBlendMode(.clear)
            for p in erasePoints {
                let scale = inputImage.size.width / screenWidth
                let pt = CGPoint(x: p.point.x * scale, y: p.point.y * scale)
                let sz = p.size * scale
                let rect = CGRect(x: pt.x - sz / 2, y: pt.y - sz / 2, width: sz, height: sz)
                ctx.cgContext.fillEllipse(in: rect)
            }
        }
    }

    // MARK: - Адаптивный размер
    func aspectFitSize(for imageSize: CGSize, in containerSize: CGSize) -> CGSize {
        let aspectRatio = imageSize.width / imageSize.height
        let containerRatio = containerSize.width / containerSize.height
        if aspectRatio > containerRatio {
            let width = containerSize.width
            return CGSize(width: width, height: width / aspectRatio)
        } else {
            let height = containerSize.height
            return CGSize(width: height * aspectRatio, height: height)
        }
    }
}
