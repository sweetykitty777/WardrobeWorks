import Foundation
import SwiftUI

@MainActor
class OutfitDetailViewModel: ObservableObject {
    let outfit: OutfitResponse

    @Published var clothes: [ClothItem] = []
    @Published var scheduledDates: [Date] = []
    @Published var showShareSheet = false
    @Published var imageToShare: UIImage?
    @Published var isDeleting = false
    @Published var showDeleteErrorAlert = false
    @Published var showDatePicker = false
    @Published var selectedDate = Date()
    @Published var showEditView = false

    init(outfit: OutfitResponse) {
        self.outfit = outfit
    }

    func loadInitialData() {
        fetchOutfitClothes()
        fetchScheduledDates()
    }

    func fetchOutfitClothes() {
        OutfitService.shared.fetchOutfitClothes(outfitId: outfit.id) { [weak self] clothes in
            self?.clothes = clothes
        }
    }

    func fetchScheduledDates() {
        CalendarService.shared.fetchScheduledDates(for: outfit.id) { [weak self] dates in
            self?.scheduledDates = dates
        }
    }

    func deleteOutfit(completion: @escaping (Bool) -> Void) {
        isDeleting = true
        OutfitService.shared.deleteOutfit(id: outfit.id) { [weak self] success in
            self?.isDeleting = false
            if !success {
                self?.showDeleteErrorAlert = true
            }
            completion(success)
        }
    }

    func deleteCalendarEntry(for date: Date) {
        CalendarService.shared.deleteEntry(for: outfit.id, date: date) { [weak self] success in
            if success {
                self?.scheduledDates.removeAll { Calendar.current.isDate($0, inSameDayAs: date) }
            } else {
                print("❌ Не удалось удалить запись из календаря.")
            }
        }
    }

    func shareImage(from urlString: String) {
        ImageShareService.fetchImage(from: urlString) { [weak self] image in
            self?.imageToShare = image
            self?.showShareSheet = image != nil
        }
    }

    func scheduleOutfitDate() {
        CalendarService.shared.scheduleOutfit(outfitId: outfit.id, date: selectedDate) { [weak self] result in
            if case .success = result {
                self?.fetchScheduledDates()
                self?.showDatePicker = false
            } else {
                print("❌ Не удалось назначить образ на дату")
            }
        }
    }
}
