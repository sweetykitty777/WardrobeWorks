import Foundation
import Combine

class CommentsViewModel: ObservableObject {
    let postId: Int

    @Published var comments: [Comment] = []
    @Published var newCommentText: String = ""
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var currentUserId: Int?

    private var cancellables = Set<AnyCancellable>()

    init(postId: Int) {
        self.postId = postId
    }

    /// Вызывается вручную из `.onAppear`, безопасно инициирует загрузку
    func start() {
        isLoading = true
        fetchCurrentUserAndComments()
    }

    private func fetchCurrentUserAndComments() {
        UserProfileService.shared.fetchProfile { [weak self] result in
            DispatchQueue.main.async {
                switch result {
                case .success(let user):
                    self?.currentUserId = user.id
                    self?.fetchComments()
                case .failure(let error):
                    self?.isLoading = false
                    self?.errorMessage = "Ошибка загрузки профиля: \(error.localizedDescription)"
                }
            }
        }
    }

    func fetchComments() {
        guard let url = URL(string: "https://gate-acidnaya.amvera.io/api/v1/social-service/comments/\(postId)") else { return }

        var req = URLRequest(url: url)
        req.httpMethod = "GET"
        if let token = KeychainHelper.get(forKey: "accessToken") {
            req.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }

        URLSession.shared.dataTaskPublisher(for: req)
            .map(\.data)
            .decode(type: [Comment].self, decoder: JSONDecoder())
            .receive(on: DispatchQueue.main)
            .sink { [weak self] completion in
                self?.isLoading = false
                if case let .failure(err) = completion {
                    self?.errorMessage = "Не удалось загрузить комментарии: \(err.localizedDescription)"
                }
            } receiveValue: { [weak self] comments in
                self?.comments = comments
            }
            .store(in: &cancellables)
    }

    func addComment() {
        let trimmed = newCommentText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }

        guard let url = URL(string: "https://gate-acidnaya.amvera.io/api/v1/social-service/comments/\(postId)/add") else { return }

        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.addValue("application/json", forHTTPHeaderField: "Content-Type")
        if let token = KeychainHelper.get(forKey: "accessToken") {
            req.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }

        let body = ["text": trimmed]
        req.httpBody = try? JSONEncoder().encode(body)

        newCommentText = ""

        URLSession.shared.dataTask(with: req) { [weak self] _, response, error in
            DispatchQueue.main.async {
                if let err = error {
                    self?.errorMessage = "Ошибка отправки: \(err.localizedDescription)"
                    return
                }

                guard let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode) else {
                    self?.errorMessage = "Сервер вернул ошибку"
                    return
                }

                self?.fetchComments()
            }
        }.resume()
    }

    func deleteComment(_ commentId: Int) {
        guard let url = URL(string: "https://gate-acidnaya.amvera.io/api/v1/social-service/comments/\(commentId)") else { return }

        var req = URLRequest(url: url)
        req.httpMethod = "DELETE"
        if let token = KeychainHelper.get(forKey: "accessToken") {
            req.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }

        URLSession.shared.dataTask(with: req) { [weak self] _, response, error in
            DispatchQueue.main.async {
                if let err = error {
                    self?.errorMessage = "Ошибка удаления: \(err.localizedDescription)"
                    return
                }

                guard let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode) else {
                    self?.errorMessage = "Не удалось удалить комментарий"
                    return
                }

                self?.comments.removeAll { $0.id == commentId }
            }
        }.resume()
    }
}
