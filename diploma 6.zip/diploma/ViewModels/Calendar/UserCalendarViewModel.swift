import Foundation
import SwiftUI

class UserCalendarViewModel: ObservableObject {
    @Published var scheduledOutfits: [ScheduledOutfitResponse] = []
    @Published var isLoading = false
    @Published var errorMessage: String? = nil

    private var userId: Int
    private let calendar = Calendar.current

    init(userId: Int) {
        self.userId = userId
    }

    func fetchCalendar() {
        isLoading = true
        errorMessage = nil

        CalendarService.shared.fetchUserCalendars(userId: userId) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let calendars):
                    guard let firstCalendar = calendars.first else {
                        self.isLoading = false
                        self.errorMessage = "Нет доступных календарей у пользователя."
                        return
                    }
                    self.fetchCalendarEntries(calendarId: firstCalendar.id)
                case .failure(let error):
                    self.isLoading = false
                    self.errorMessage = error.localizedDescription
                }
            }
        }
    }

    private func fetchCalendarEntries(calendarId: Int) {
        CalendarService.shared.fetchCalendarEntries(calendarId: calendarId) { result in
            DispatchQueue.main.async {
                self.isLoading = false
                switch result {
                case .success(let entries):
                    self.scheduledOutfits = entries
                case .failure(let error):
                    self.errorMessage = error.localizedDescription
                }
            }
        }
    }

    /// Возвращает запланированный аутфит, если он есть на конкретную дату
    func scheduledOutfit(for date: Date) -> ScheduledOutfitResponse? {
        scheduledOutfits.first {
            calendar.isDate($0.date, inSameDayAs: date)
        }
    }
}
