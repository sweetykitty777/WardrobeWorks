import SwiftUI

struct CustomMenuOverlay: View {
    @Binding var showingMenu: Bool
    @Binding var showingAddItemSheet: Bool
    @Binding var showingAddOutfitSheet: Bool
    @Binding var showingAddPostSheet: Bool

    @State private var dragOffset = CGSize.zero
    @State private var appearOffset: CGFloat = UIScreen.main.bounds.height // начальное положение за экраном

    var body: some View {
        VStack(spacing: 12) {
            Capsule()
                .fill(Color.gray.opacity(0.4))
                .frame(width: 40, height: 5)
                .padding(.top, 12)

            menuButton(title: "Добавить вещь") {
                showingMenu = false
                showingAddItemSheet = true
            }

            menuButton(title: "Создать аутфит") {
                showingMenu = false
                showingAddOutfitSheet = true
            }

            menuButton(title: "Создать пост") {
                showingMenu = false
                showingAddPostSheet = true
            }

            Spacer()
        }
        .padding(.top, 16)
        .padding(.horizontal)
        .frame(maxWidth: .infinity)
        .frame(height: UIScreen.main.bounds.height * 0.25)
        .background(
            Color.white
                .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
        )
        .offset(y: appearOffset + (dragOffset.height > 0 ? dragOffset.height : 0)) // 🔥 Добавляем красивое появление + свайп
        .gesture(
            DragGesture()
                .onChanged { gesture in
                    if gesture.translation.height > 0 {
                        dragOffset = gesture.translation
                    }
                }
                .onEnded { gesture in
                    if gesture.translation.height > 100 {
                        withAnimation(.spring()) {
                            showingMenu = false
                        }
                    }
                    dragOffset = .zero
                }
        )
        .onAppear {
            withAnimation(.spring(response: 0.5, dampingFraction: 0.8)) {
                appearOffset = 0 // когда появляется экран — двигаем наверх плавно
            }
        }
        .onChange(of: showingMenu) { value in
            if !value {
                withAnimation(.easeInOut(duration: 0.4)) {
                    appearOffset = UIScreen.main.bounds.height
                }
            }
        }
    }

    @ViewBuilder
    private func menuButton(title: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack {
                Text(title)
                    .font(.system(size: 17, weight: .medium))
                    .foregroundColor(.primary)
                Spacer()
                Image(systemName: "chevron.right")
                    .foregroundColor(.gray)
            }
            .padding()
            .frame(maxWidth: .infinity)
            .background(Color(UIColor.systemGray6))
            .cornerRadius(14)
            .shadow(color: Color.black.opacity(0.05), radius: 3, x: 0, y: 1)
        }
    }
}
