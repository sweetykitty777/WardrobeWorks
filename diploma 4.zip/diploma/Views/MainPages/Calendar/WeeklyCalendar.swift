import SwiftUI

struct WeeklyCalendarView: View {
    @StateObject private var viewModel = WeeklyCalendarViewModel()
    @StateObject private var statsViewModel = ClothingStatsViewModel()
    @StateObject private var calendarOutfitViewModel = CalendarOutfitViewModel()
    @StateObject private var outfitViewModel = OutfitViewModel()

    @State private var posts: [Post] = []
    @State private var showingDatePicker = false
    @State private var showingAddItemSheet = false
    @State private var showingAddOutfitSheet = false
    @State private var showingAddPostSheet = false
    @State private var showingScheduleOutfit = false
    @State private var showingShareAccessSheet = false
    @State private var showingMenu = false
    @State private var selectedTab: Int = 0

    var body: some View {
        ZStack {
            VStack(spacing: 0) {
                TabView(selection: $selectedTab) {
                    VStack(spacing: 0) {
                        HeaderView(
                            showingDatePicker: $showingDatePicker,
                            selectedDate: $viewModel.selectedDate,
                            onDateSelected: { newDate in
                                viewModel.selectDate(newDate)
                            },
                            onShareAccessTapped: {
                                showingShareAccessSheet = true
                            }
                        )

                        WeekNavigationView(viewModel: viewModel)
                        DaysScrollView(viewModel: viewModel)

                        let scheduledVM = ScheduledOutfitViewModel(
                            scheduledOutfit: viewModel.selectedScheduledOutfit,
                            onDelete: {
                                viewModel.updateCurrentWeek()
                            }
                        )
                        ScheduledOutfitView(
                            viewModel: scheduledVM,
                            showingAddOutfitSheet: $showingScheduleOutfit
                        )

                        ClothingStatsView(viewModel: statsViewModel)
                        Spacer()
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
                    .onAppear {
                        viewModel.updateCurrentWeek()
                        statsViewModel.fetchClothingStats()
                    }
                    .tabItem {
                        Image(systemName: "calendar")
                        Text("Календарь")
                    }
                    .tag(0)

                    WardrobeTabView()
                        .tabItem {
                            Image(systemName: "tshirt")
                            Text("Гардероб")
                        }
                        .tag(1)

                    Color.clear
                        .tabItem {
                            PlusTabButton()
                        }
                        .tag(2)
                        .onAppear {
                            showingMenu = true
                            selectedTab = 0
                        }

                    InspirationView()
                        .tabItem {
                            Image(systemName: "lightbulb")
                            Text("Вдохновение")
                        }
                        .tag(3)

                    UserProfileView()
                        .tabItem {
                            Image(systemName: "person")
                            Text("Профиль")
                        }
                        .tag(4)
                }
            }

            if showingMenu {
                CustomMenuOverlay(
                    showingMenu: $showingMenu,
                    showingAddItemSheet: $showingAddItemSheet,
                    showingAddOutfitSheet: $showingAddOutfitSheet,
                    showingAddPostSheet: $showingAddPostSheet
                )
                .offset(y: showingMenu ? 0 : UIScreen.main.bounds.height)
                .animation(.spring(), value: showingMenu)
            }
        }
        .background(Color.white.ignoresSafeArea())

        .sheet(isPresented: $showingAddItemSheet) {
            AddClothingItemView(viewModel: AddClothingItemViewModel())
        }

        .sheet(isPresented: $showingAddOutfitSheet) {
            CreateOutfitView(viewModel: outfitViewModel)
        }

        .sheet(isPresented: $showingAddPostSheet) {
            CreatePostView(posts: $posts, outfitViewModel: outfitViewModel)
        }

        .sheet(isPresented: $showingScheduleOutfit) {
            ScheduleOutfitView(
                viewModel: ScheduleOutfitViewModel(date: viewModel.selectedDate),
                onSuccess: {
                    viewModel.updateCurrentWeek()
                }
            )
        }

        .sheet(isPresented: $showingShareAccessSheet) {
            ShareAccessView(viewModel: ShareAccessViewModel(wardrobeId: 1)) // Заглушка
        }
    }
}
