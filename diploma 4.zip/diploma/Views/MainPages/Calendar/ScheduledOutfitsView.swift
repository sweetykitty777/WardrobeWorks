import SwiftUI

struct ScheduledOutfitView: View {
    @ObservedObject var viewModel: ScheduledOutfitViewModel
    @Binding var showingAddOutfitSheet: Bool

    var body: some View {
        if let scheduled = viewModel.scheduledOutfit {
            VStack(spacing: 8) {
                // Кнопки обновить/удалить справа
                HStack {
                    Spacer()
                    Button(action: { showingAddOutfitSheet = true }) {
                        Image(systemName: "arrow.triangle.2.circlepath")
                            .foregroundColor(.blue)
                    }
                    Button(role: .destructive) {
                        viewModel.deleteScheduled()
                    } label: {
                        Image(systemName: "trash")
                            .foregroundColor(.red)
                    }
                }

                // Центрируем карточку по горизонтали
                FullWidthOutfitCard(outfit: scheduled.outfit)
                    .padding(.top, 4)
                    .frame(maxWidth: .infinity, alignment: .center)

            }
            .padding(.horizontal)
            .padding(.bottom)
            .overlay(
                toastOverlay,
                alignment: .top
            )
        } else {
            AddOutfitButton(showingAddOutfitSheet: $showingAddOutfitSheet)
                .frame(maxWidth: .infinity)
        }
    }

    private var toastOverlay: some View {
        Group {
            if viewModel.showToast {
                Text(viewModel.toastMessage)
                    .font(.subheadline)
                    .foregroundColor(.white)
                    .padding(10)
                    .background(viewModel.toastColor)
                    .cornerRadius(12)
                    .padding(.top, 10)
                    .transition(.move(edge: .top).combined(with: .opacity))
                    .onAppear {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                            withAnimation { viewModel.showToast = false }
                        }
                    }
            }
        }
    }
}
