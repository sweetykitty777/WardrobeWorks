import SwiftUI

struct OutfitCard: View {
    let outfit: OutfitResponse

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            if let imagePath = outfit.imagePath, !imagePath.isEmpty {
                RemoteImageView(urlString: imagePath)
                    .frame(height: 140)
                    .clipShape(RoundedRectangle(cornerRadius: 12))
            } else {
                ZStack {
                    RoundedRectangle(cornerRadius: 12)
                        .fill(Color.gray.opacity(0.1))
                        .frame(height: 140)

                    Image(systemName: "photo")
                        .font(.system(size: 36))
                        .foregroundColor(.gray)
                }
            }
        }
        .padding()
        .background(Color.white)
        .cornerRadius(16)
        .shadow(color: Color.black.opacity(0.05), radius: 4, x: 0, y: 2)
    }

    private func formatted(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "dd.MM.yyyy"
        return formatter.string(from: date)
    }
}
