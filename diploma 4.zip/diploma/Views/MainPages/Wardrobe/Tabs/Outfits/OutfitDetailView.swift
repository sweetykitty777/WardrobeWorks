import SwiftUI

struct OutfitDetailView: View {
    let outfit: OutfitResponse

    @State private var clothes: [ClothItem] = []
    @State private var showShareSheet = false
    @State private var imageToShare: UIImage?

    private let columns = [
        GridItem(.flexible(), spacing: 12),
        GridItem(.flexible(), spacing: 12)
    ]

    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                // Изображение аутфита
                if let imagePath = outfit.imagePath {
                    RemoteImageView(urlString: imagePath)
                        .frame(height: 220)
                        .clipShape(RoundedRectangle(cornerRadius: 20))
                        .padding(.horizontal)
                        .padding(.top)
                        .background(Color.white)
                        .cornerRadius(20)
                        .shadow(color: Color.black.opacity(0.05), radius: 8, x: 0, y: 4)
                        .onTapGesture {
                            shareImage(from: imagePath)
                        }
                }

                // Состав аутфита
                if !clothes.isEmpty {
                    Text("Состав аутфита")
                        .font(.headline)
                        .padding(.horizontal)

                    LazyVGrid(columns: columns, spacing: 16) {
                        ForEach(clothes, id: \.id) { item in
                            NavigationLink(destination: ClothingDetailView(item: item)) {
                                ClothItemViewNotSelectable(item: item)
                                    .frame(height: 160)
                            }
                            .buttonStyle(PlainButtonStyle())
                        }
                    }
                    .padding(.horizontal)
                } else {
                    Text("Нет вещей в этом аутфите")
                        .font(.subheadline)
                        .foregroundColor(.gray)
                        .padding()
                }

                Spacer(minLength: 20)
            }
        }
        .background(Color(.systemGroupedBackground).ignoresSafeArea())
        .onAppear {
            fetchOutfitClothes()
        }
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                if imageToShare != nil {
                    Button(action: {
                        showShareSheet = true
                    }) {
                        Image(systemName: "square.and.arrow.up")
                            .foregroundColor(.blue)
                    }
                }
            }
        }
        .sheet(isPresented: $showShareSheet) {
            if let image = imageToShare {
                ActivityView(activityItems: [image])
            }
        }
    }

    private func fetchOutfitClothes() {
        guard let url = URL(string: "https://gate-acidnaya.amvera.io/api/v1/wardrobe-service/outfits/\(outfit.id)/clothes") else { return }

        var request = URLRequest(url: url)
        request.httpMethod = "GET"

        if let token = KeychainHelper.get(forKey: "accessToken") {
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }

        URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                if let data = data {
                    // 🔥 Выводим сырые данные до декодирования
                    if let rawString = String(data: data, encoding: .utf8) {
                        print("📦 RAW данные сервера:\n\(rawString)")
                    }

                    do {
                        clothes = try JSONDecoder().decode([ClothItem].self, from: data)
                        print("✅ Загрузили \(clothes.count) вещей")
                    } catch {
                        print("❌ Ошибка декодирования вещей:", error.localizedDescription)
                    }
                } else if let error = error {
                    print("❌ Ошибка сети:", error.localizedDescription)
                }
            }
        }.resume()
    }

    private func shareImage(from urlString: String) {
        guard let url = URL(string: urlString) else { return }

        URLSession.shared.dataTask(with: url) { data, _, _ in
            if let data = data, let image = UIImage(data: data) {
                DispatchQueue.main.async {
                    imageToShare = image
                    showShareSheet = true
                }
            }
        }.resume()
    }
}


struct ActivityView: UIViewControllerRepresentable {
    let activityItems: [Any]
    let applicationActivities: [UIActivity]? = nil

    func makeUIViewController(context: Context) -> UIActivityViewController {
        return UIActivityViewController(activityItems: activityItems, applicationActivities: applicationActivities)
    }

    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {
        // Ничего обновлять не нужно
    }
}
