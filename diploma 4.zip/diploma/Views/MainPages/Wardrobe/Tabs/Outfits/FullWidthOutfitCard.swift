//
//  FullWidthOutfitCard.swift
//  diploma
//
//  Created by Olga on 24.04.2025.
//

import Foundation
import SwiftUI

struct FullWidthOutfitCard: View {
    let outfit: OutfitResponse

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            if let imagePath = outfit.imagePath, !imagePath.isEmpty {
                RemoteImageView(
                    urlString: imagePath,
                    cornerRadius: 16,
                    width: 250,
                    height: 250
                )
            } else {
                ZStack {
                    RoundedRectangle(cornerRadius: 16)
                        .fill(Color.gray.opacity(0.1))
                        .frame(width: 250, height: 250)

                    Image(systemName: "photo")
                        .font(.system(size: 48))
                        .foregroundColor(.gray)
                }
            }

         /*   VStack(alignment: .leading, spacing: 4) {
                if let date = outfit.createdAt {
                    Text("Создан: \(formatted(date))")
                        .font(.footnote)
                        .foregroundColor(.gray)
                }
            }
            .padding(.horizontal, 8)*/
        }
        .frame(width: 250)
        .background(Color.white)
        .cornerRadius(20)
        .shadow(color: Color.black.opacity(0.08), radius: 6, x: 0, y: 3)
    }

    private func formatted(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "dd.MM.yyyy"
        return formatter.string(from: date)
    }
}
