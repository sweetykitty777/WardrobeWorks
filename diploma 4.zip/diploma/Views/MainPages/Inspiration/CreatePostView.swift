import SwiftUI

struct CreatePostView: View {
    @Binding var posts: [Post]
    @ObservedObject var outfitViewModel: OutfitViewModel
    @StateObject private var viewModel = CreatePostViewModel()

    var body: some View {
        NavigationView {
            VStack(spacing: 16) {

                // Выбор гардероба
                Menu {
                    ForEach(viewModel.wardrobes, id: \..id) { wardrobe in
                        Button(wardrobe.name) {
                            viewModel.selectedWardrobeId = wardrobe.id
                            loadOutfits(for: wardrobe.id)
                        }
                    }
                } label: {
                    HStack {
                        Text(selectedWardrobeName)
                        Spacer()
                        Image(systemName: "chevron.down")
                    }
                    .padding()
                    .background(Color.white)
                    .cornerRadius(10)
                    .shadow(radius: 1)
                }
                .padding(.horizontal)

                // Выбор аутфита
                ScrollView {
                    LazyVStack(spacing: 10) {
                        ForEach(outfitViewModel.outfits) { outfit in
                            HStack {
                                if let imagePath = outfit.imagePath,
                                   let url = URL(string: imagePath) {
                                    AsyncImage(url: url) { phase in
                                        switch phase {
                                        case .success(let image): image.resizable()
                                        default: Color.gray
                                        }
                                    }
                                    .frame(width: 80, height: 80)
                                    .clipShape(RoundedRectangle(cornerRadius: 10))
                                }

                                Text(outfit.name)
                                    .font(.headline)
                                    .foregroundColor(.primary)

                                Spacer()

                                if viewModel.selectedOutfit?.id == outfit.id {
                                    Image(systemName: "checkmark.circle.fill")
                                        .foregroundColor(.blue)
                                }
                            }
                            .padding()
                            .background(Color.white)
                            .cornerRadius(10)
                            .shadow(radius: 1)
                            .onTapGesture {
                                viewModel.selectedOutfit = outfit
                            }
                        }
                    }
                    .padding(.horizontal)
                }

                TextField("Описание поста", text: $viewModel.description)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding(.horizontal)

                Button("Опубликовать пост") {
                    viewModel.createPost()
                }
                .disabled(viewModel.selectedOutfit == nil || viewModel.description.isEmpty)
                .padding()
                .frame(maxWidth: .infinity)
                .background((viewModel.selectedOutfit == nil || viewModel.description.isEmpty) ? Color.gray : Color.blue)
                .foregroundColor(.white)
                .cornerRadius(10)
                .padding(.horizontal)

                Spacer()
            }
            .navigationTitle("Создать пост")
            .onAppear {
                viewModel.fetchWardrobes()
            }
            .overlay(toastOverlay, alignment: .top)
        }
    }

    private var selectedWardrobeName: String {
        if let id = viewModel.selectedWardrobeId,
           let wardrobe = viewModel.wardrobes.first(where: { $0.id == id }) {
            return wardrobe.name
        }
        return "Выбрать гардероб"
    }

    private func loadOutfits(for wardrobeId: Int) {
        viewModel.isLoading = true
        outfitViewModel.fetchOutfits(for: wardrobeId)

        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
            viewModel.isLoading = false
            if outfitViewModel.outfits.isEmpty {
                viewModel.showToast(message: "❌ Не удалось загрузить аутфиты")
            }
        }
    }

    private var toastOverlay: some View {
        Group {
            if viewModel.showToast {
                Text(viewModel.toastMessage)
                    .font(.subheadline)
                    .foregroundColor(.white)
                    .padding()
                    .background(Color.black)
                    .cornerRadius(10)
                    .padding(.top, 20)
                    .transition(.move(edge: .top).combined(with: .opacity))
            }
        }
    }
}

