import Foundation

class CalendarService {
    static let shared = CalendarService()

    private init() {}

    // MARK: - Schedule Outfit
    func scheduleOutfit(outfitId: Int, date: Date, completion: @escaping (Result<Void, Error>) -> Void) {
        guard let url = URL(string: "https://gate-acidnaya.amvera.io/api/v1/wardrobe-service/calendar/create") else {
            print("❌ Невалидный URL для планирования")
            completion(.failure(NSError(domain: "Invalid URL", code: 400)))
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "PUT"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        if let token = KeychainHelper.get(forKey: "accessToken") {
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
            print("🔐 Токен авторизации добавлен")
        }

        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"

        let body: [String: Any] = [
            "outfitId": outfitId,
            "date": formatter.string(from: date)
        ]

        do {
            let jsonData = try JSONSerialization.data(withJSONObject: body)
            request.httpBody = jsonData
            print("📤 Отправка данных: \(String(data: jsonData, encoding: .utf8) ?? "")")
        } catch {
            print("❌ Ошибка сериализации JSON: \(error)")
            completion(.failure(error))
            return
        }

        URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                if let error = error {
                    print("❌ Ошибка сети: \(error)")
                    completion(.failure(error))
                    return
                }

                if let httpResponse = response as? HTTPURLResponse {
                    print("📬 Код ответа: \(httpResponse.statusCode)")

                    if (200..<300).contains(httpResponse.statusCode) {
                        completion(.success(()))
                    } else {
                        let message = String(data: data ?? Data(), encoding: .utf8) ?? "Нет сообщения"
                        print("❌ Ошибка от сервера: \(message)")
                        completion(.failure(NSError(domain: "Server error", code: httpResponse.statusCode)))
                    }
                } else {
                    print("❌ Нет валидного ответа")
                    completion(.failure(NSError(domain: "No response", code: 500)))
                }
            }
        }.resume()
    }

    // MARK: - Delete Scheduled Outfit
    func deleteScheduledOutfit(entryId: Int, completion: @escaping (Result<Void, Error>) -> Void) {
        guard let url = URL(string: "https://gate-acidnaya.amvera.io/api/v1/wardrobe-service/calendar/\(entryId)") else {
            print("❌ Невалидный URL")
            completion(.failure(NSError(domain: "Invalid URL", code: 400)))
            return
        }

        print("🌐 DELETE запрос на: \(url.absoluteString)")

        var request = URLRequest(url: url)
        request.httpMethod = "DELETE"

        if let token = KeychainHelper.get(forKey: "accessToken") {
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
            print("🔐 Заголовок Authorization: Bearer \(token)...") // сокращаем вывод
        } else {
            print("⚠️ Токен не найден")
            completion(.failure(NSError(domain: "No token", code: 401)))
            return
        }

        URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                if let error = error {
                    print("❌ Ошибка запроса: \(error)")
                    completion(.failure(error))
                    return
                }

                if let httpResponse = response as? HTTPURLResponse {
                    print("📬 Код ответа: \(httpResponse.statusCode)")
                }

                if let data = data, let raw = String(data: data, encoding: .utf8) {
                    print("📦 Ответ сервера:\n\(raw)")
                }

                if let httpResponse = response as? HTTPURLResponse,
                   !(200..<300).contains(httpResponse.statusCode) {
                    completion(.failure(NSError(domain: "Server error", code: httpResponse.statusCode)))
                } else {
                    print("✅ Удаление прошло успешно")
                    completion(.success(()))
                }
            }
        }.resume()
    }



}
