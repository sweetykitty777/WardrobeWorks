//
//  ScheduledOutfitResponse.swift
//  diploma
//
//  Created by Olga on 23.04.2025.
//

import Foundation

struct ScheduledOutfitResponse: Identifiable, Codable {
    let id: Int
    let userId: Int
    let outfit: OutfitResponse
    let date: Date
}
