//  WardrobeServiceWardrobe.swift
//  diploma
//
//  Created by Olga on 04.05.2025.

import Foundation

extension WardrobeService {

    func createWardrobe(request payload: CreateWardrobeRequest, completion: @escaping (Result<Void, Error>) -> Void) {
        guard let body = try? JSONEncoder().encode(payload) else {
            return completion(.failure(NSError(domain: "Encoding error", code: 500)))
        }

        api.requestVoid(
            path: "/wardrobe-service/wardrobes/create",
            method: "POST",
            body: body,
            completion: completion
        )
    }

    func getWardrobe(by id: Int, completion: @escaping (Result<UsersWardrobe, Error>) -> Void) {
        api.request(
            path: "/wardrobe-service/wardrobes/\(id)",
            method: "GET",
            decodeTo: UsersWardrobe.self,
            completion: completion
        )
    }


    func fetchWardrobes(completion: @escaping (Result<[UsersWardrobe], Error>) -> Void) {
        if let cached = wardrobeCache.cachedWardrobes, wardrobeCache.isWardrobeCacheValid(ttl: cacheTTL) {
            completion(.success(cached))
            return
        }

        api.request(
            path: "/wardrobe-service/wardrobes/all",
            method: "GET",
            decodeTo: [UsersWardrobe].self
        ) { [weak self] result in
            DispatchQueue.main.async {
                switch result {
                case .success(let wardrobes):
                    self?.wardrobeCache.cachedWardrobes = wardrobes
                    self?.wardrobeCache.lastFetchTime = Date()
                    self?.saveCache(wardrobes, for: "all")
                case .failure:
                    if let fallback: [UsersWardrobe] = self?.loadCache(for: "all") {
                        completion(.success(fallback))
                        return
                    }
                }
                completion(result)
            }
        }
    }


    func getWardrobes(of userId: Int, completion: @escaping (Result<[UsersWardrobe], Error>) -> Void) {
        api.request(
            path: "/wardrobe-service/wardrobes/\(userId)/all",
            method: "GET",
            decodeTo: [UsersWardrobe].self,
            completion: completion
        )
    }

    func changeWardrobePrivacy(id: Int, isPrivate: Bool, completion: @escaping (Result<Void, Error>) -> Void) {
        let query = "?isPrivate=\(isPrivate)"
        api.requestVoid(
            path: "/wardrobe-service/wardrobes/\(id)/change-privacy\(query)",
            method: "PATCH",
            completion: completion
        )
    }

    func removeWardrobe(id: Int, completion: @escaping (Result<Void, Error>) -> Void) {
        api.requestVoid(
            path: "/wardrobe-service/wardrobes/\(id)/remove",
            method: "PATCH",
            completion: completion
        )
    }
}
