//
//  WardrobeServiceImageUpload.swift
//  diploma
//
//  Created by Olga on 04.05.2025.
//

import Foundation
import UIKit

extension WardrobeService {

    func uploadImage(_ image: UIImage, completion: @escaping (Result<String, Error>) -> Void) {
        upload(image: image, as: .jpeg, completion: completion)
    }

    func uploadPNGImage(_ image: UIImage, completion: @escaping (Result<String, Error>) -> Void) {
        upload(image: image, as: .png, completion: completion)
    }

    // MARK: - Private

    private enum ImageFormat {
        case jpeg
        case png

        var contentType: String {
            switch self {
            case .jpeg: return "image/jpeg"
            case .png:  return "image/png"
            }
        }

        var fileExtension: String {
            switch self {
            case .jpeg: return "jpg"
            case .png:  return "png"
            }
        }

        func imageData(from image: UIImage) -> Data? {
            switch self {
            case .jpeg:
                return image.jpegData(compressionQuality: 0.8)
            case .png:
                return image.pngData()
            }
        }
    }

    private func upload(image: UIImage, as format: ImageFormat, completion: @escaping (Result<String, Error>) -> Void) {
        guard let url = URL(string: "https://gate-acidnaya.amvera.io/api/v1/wardrobe-service/images/upload") else {
            return completion(.failure(NSError(domain: "Invalid URL", code: 400)))
        }

        guard let imageData = format.imageData(from: image) else {
            return completion(.failure(NSError(domain: "Invalid image data", code: 400)))
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"

        let boundary = UUID().uuidString
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")

        if let token = KeychainHelper.get(forKey: "accessToken") {
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }

        var body = Data()
        body.append("--\(boundary)\r\n".data(using: .utf8)!)
        body.append("Content-Disposition: form-data; name=\"file\"; filename=\"image.\(format.fileExtension)\"\r\n".data(using: .utf8)!)
        body.append("Content-Type: \(format.contentType)\r\n\r\n".data(using: .utf8)!)
        body.append(imageData)
        body.append("\r\n--\(boundary)--\r\n".data(using: .utf8)!)
        request.httpBody = body

        URLSession.shared.dataTask(with: request) { data, _, error in
            DispatchQueue.main.async {
                if let error = error {
                    return completion(.failure(error))
                }

                guard let data = data,
                      let path = String(data: data, encoding: .utf8)?
                        .trimmingCharacters(in: CharacterSet(charactersIn: "\" \n\r")) else {
                    return completion(.failure(NSError(domain: "Invalid response", code: 500)))
                }

                let fullUrl = "https://gate-acidnaya.amvera.io/images/" + path
                completion(.success(fullUrl))
            }
        }.resume()
    }
}
