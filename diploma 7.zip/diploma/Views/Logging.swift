//
//  Logging.swift
//  diploma
//
//  Created by Olga on 09.05.2025.
//

import os
import Foundation

let logger = Logger(subsystem: Bundle.main.bundleIdentifier ?? "com.yourapp.identifier", category: "General")
