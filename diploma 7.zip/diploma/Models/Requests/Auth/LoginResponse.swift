//
//  LoginResponse.swift
//  diploma
//
//  Created by Olga on 13.04.2025.
//

import Foundation
struct LoginResponse: Codable, Hashable {
    let token: String
}
