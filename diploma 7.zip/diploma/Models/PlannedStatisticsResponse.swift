//
//  PlannedStatisticsResponse.swift
//  diploma
//
//  Created by Olga on 11.05.2025.
//
import Foundation

struct PlannedStatisticsResponse: Codable {
    let outfitsNumber: Int
    let clothesNumber: Int
}
