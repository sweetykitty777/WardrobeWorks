//
//  FavouriteColor.swift
//  diploma
//
//  Created by Olga on 11.05.2025.
//
import Foundation

struct FavouriteColour: Codable {
    let id: Int
    let name: String
    let colourcode: String
}
