//
//  StatisticsRequest.swift
//  diploma
//
//  Created by Olga on 11.05.2025.
//
import Foundation

struct StatisticsRequest: Codable {
    let startDate: Date
    let endDate: Date
}
