//
//  FavouriteBrand.swift
//  diploma
//
//  Created by Olga on 11.05.2025.
//
import Foundation

struct FavouriteBrand: Codable {
    let id: Int
    let name: String
}
