import SwiftUI
import PostHog

class CreateOutfitViewModel: ObservableObject {
    @Published var wardrobes: [UsersWardrobe] = []
    @Published var selectedWardrobeId: Int?
    @Published var selectedWardrobeName: String = "Выбрать гардероб"

    @Published var placedItems: [PlacedClothingItem] = []
    @Published var imageURLsByClothId: [Int: String] = [:]

    @Published var showingWardrobe: Bool = false
    @Published var showToast: Bool = false
    @Published var toastMessage: String = ""
    @Published var isSaving: Bool = false

    private var renderedImages: [Int: UIImage] = [:]

    func selectWardrobe(_ wardrobe: UsersWardrobe) {
        selectedWardrobeId = wardrobe.id
        selectedWardrobeName = wardrobe.name
    }

    func fetchWardrobes() {
        WardrobeService.shared.fetchWardrobes { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let list):
                    self.wardrobes = list
                    PostHogSDK.shared.capture("create outfit wardrobe loaded", properties: [
                        "count": list.count
                    ])
                case .failure(let error):
                    self.toastMessage = "Ошибка загрузки гардеробов: \(error.localizedDescription)"
                    self.showToast = true
                    PostHogSDK.shared.capture("create outfit wardrobe failed", properties: [
                        "error": error.localizedDescription
                    ])
                }
            }
        }
    }

    func fetchOutfit(id: Int, completion: @escaping (Result<OutfitResponse, Error>) -> Void) {
        WardrobeService.shared.fetchOutfit(id: id) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let outfit):
                    completion(.success(outfit))
                case .failure(let error):
                    completion(.failure(error))
                }
            }
        }
    }

    func removeItem(_ item: PlacedClothingItem) {
        placedItems.removeAll { $0.clothId == item.clothId }
        PostHogSDK.shared.capture("create outfit item removed", properties: [
            "cloth_id": item.clothId
        ])
    }

    func saveOutfit(onComplete: @escaping () -> Void) {
        guard let wardrobeId = selectedWardrobeId else {
            toastMessage = "Выберите гардероб"
            showToast = true
            return
        }

        isSaving = true
        PostHogSDK.shared.capture("create outfit started", properties: [
            "wardrobe_id": wardrobeId,
            "items_count": placedItems.count
        ])

        preloadImages { success in
            guard success else {
                self.toastMessage = "Ошибка загрузки изображений"
                self.showToast = true
                self.isSaving = false
                PostHogSDK.shared.capture("create outfit image failed", properties: [
                    "reason": "image preload failed"
                ])
                return
            }

            let canvasSize = self.canvasSizeForRendering()

            OutfitImageBuilder.renderImage(
                from: self.placedItems,
                images: self.renderedImages,
                canvasSize: canvasSize
            ) { image in
                guard let image = image else {
                    self.toastMessage = "Не удалось создать изображение"
                    self.showToast = true
                    self.isSaving = false
                    PostHogSDK.shared.capture("create outfit image failed", properties: [
                        "reason": "image render failed"
                    ])
                    return
                }

                PostHogSDK.shared.capture("create outfit image upload")

                WardrobeService.shared.uploadPNGImage(image) { result in
                    DispatchQueue.main.async {
                        switch result {
                        case .success(let imagePath):
                            self.sendOutfitToServer(imagePath: imagePath, wardrobeId: wardrobeId, onComplete: onComplete)
                        case .failure(let error):
                            self.toastMessage = "Ошибка загрузки изображения: \(error.localizedDescription)"
                            self.showToast = true
                            self.isSaving = false
                            PostHogSDK.shared.capture("create outfit image failed", properties: [
                                "reason": "upload failed",
                                "error": error.localizedDescription
                            ])
                        }
                    }
                }
            }
        }
    }

    private func preloadImages(completion: @escaping (Bool) -> Void) {
        let group = DispatchGroup()
        var success = true

        for item in placedItems {
            guard let urlString = imageURLsByClothId[item.clothId],
                  let url = URL(string: urlString) else { continue }

            group.enter()
            URLSession.shared.dataTask(with: url) { data, _, _ in
                defer { group.leave() }
                if let data = data, let image = UIImage(data: data) {
                    DispatchQueue.main.async {
                        self.renderedImages[item.clothId] = image
                    }
                } else {
                    success = false
                }
            }.resume()
        }

        group.notify(queue: .main) {
            completion(success)
        }
    }

    private func sendOutfitToServer(imagePath: String, wardrobeId: Int, onComplete: @escaping () -> Void) {
        let placements = placedItems.map {
            OutfitClothPlacement(
                clothId: $0.clothId,
                x: $0.x,
                y: $0.y,
                rotation: $0.rotation,
                scale: $0.scale,
                zindex: $0.zIndex
            )
        }

        let request = CreateOutfitRequest(
            name: "Новый аутфит",
            description: "",
            wardrobeId: wardrobeId,
            imagePath: imagePath,
            clothes: placements
        )

        WardrobeService.shared.createOutfit(payload: request) { result in
            DispatchQueue.main.async {
                self.isSaving = false
                switch result {
                case .success:
                    self.toastMessage = "Аутфит успешно создан"
                    self.showToast = true
                    PostHogSDK.shared.capture("create outfit success", properties: [
                        "wardrobe_id": wardrobeId,
                        "items_count": placements.count
                    ])
                    onComplete()
                case .failure(let error):
                    self.toastMessage = "Ошибка создания аутфита: \(error.localizedDescription)"
                    self.showToast = true
                    PostHogSDK.shared.capture("create outfit failed", properties: [
                        "wardrobe_id": wardrobeId,
                        "error": error.localizedDescription
                    ])
                }
            }
        }
    }

    private func canvasSizeForRendering() -> CGSize {
        guard !placedItems.isEmpty else {
            return CGSize(width: 300, height: 400)
        }

        let padding: CGFloat = 100
        let maxX = placedItems.map { $0.x + 50 * $0.scale }.max() ?? 0
        let maxY = placedItems.map { $0.y + 50 * $0.scale }.max() ?? 0

        let width = max(maxX + padding, 300)
        let height = max(maxY + padding, 400)

        return CGSize(width: width, height: height)
    }
}
