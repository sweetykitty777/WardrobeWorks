import SwiftUI

struct CollectionDetailView: View {
    @Binding var collection: Collection // ✅ Привязка к редактируемой коллекции
    @State private var showingOutfitPicker = false
    @State private var selectedOutfits: [Outfit] = [] // ✅ Выбранные для добавления аутфиты

    var body: some View {
        VStack {
            // ✅ Отображение и редактирование названия
            HStack {
                Button("Добавить аутфиты") {
                    showingOutfitPicker = true
                }
                .padding()
            }

            if collection.outfits.isEmpty {
                Text("В этой коллекции пока нет аутфитов.")
                    .foregroundColor(.gray)
                    .padding()
            } else {
                List {
                    ForEach(collection.outfits.indices, id: \.self) { index in
                        HStack {
                            OutfitCard(outfit: collection.outfits[index])
                                .contextMenu {
                                    Button("Удалить", role: .destructive) {
                                        collection.outfits.remove(at: index) // ✅ Удаление аутфита
                                    }
                                }
                        }
                    }
                    .onDelete { indexSet in
                        collection.outfits.remove(atOffsets: indexSet) // ✅ Удаление свайпом влево
                    }
                }
                .listStyle(PlainListStyle())
            }
        }
        .sheet(isPresented: $showingOutfitPicker) {
            OutfitPickerView(selectedOutfits: $selectedOutfits, onAdd: {
                collection.outfits.append(contentsOf: selectedOutfits) // ✅ Добавление аутфитов
            })
        }
        .navigationTitle(collection.name) // ✅ Отображаем название коллекции
        .navigationBarTitleDisplayMode(.inline)
    }

    // ✅ Функция скрытия клавиатуры
    private func hideKeyboard() {
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
}
