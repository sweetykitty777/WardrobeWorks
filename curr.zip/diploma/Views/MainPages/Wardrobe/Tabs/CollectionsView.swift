import SwiftUI

struct CollectionsView: View {
    @State private var collections: [Collection] = MockData.collections
    @State private var showingNewCollectionSheet = false
    @State private var editingCollectionID: UUID? // ✅ ID редактируемого лукбука

    var body: some View {
        NavigationView {
            VStack {
                List {
                    ForEach($collections, id: \.id) { $collection in
                        HStack {
                            if editingCollectionID == collection.id {
                                // ✅ Режим редактирования: TextField
                                TextField("Название лукбука", text: $collection.name, onCommit: {
                                    editingCollectionID = nil // ✅ Отключаем режим редактирования
                                })
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                                .padding(.trailing, 10)

                                Button(action: {
                                    editingCollectionID = nil // ✅ Завершаем редактирование
                                    hideKeyboard()
                                }) {
                                    Image(systemName: "checkmark.circle.fill")
                                        .foregroundColor(.green)
                                }
                            } else {
                                // ✅ Обычный режим: кнопка навигации + иконка редактирования
                                NavigationLink(destination: CollectionDetailView(collection: $collection)) {
                                    Text(collection.name)
                                        .font(.headline)
                                        .padding(.vertical, 5)
                                }

                                Spacer()

                                Button(action: {
                                    editingCollectionID = collection.id // ✅ Включаем режим редактирования
                                }) {
                                    Image(systemName: "pencil.circle.fill")
                                        .foregroundColor(.blue)
                                }
                                .buttonStyle(BorderlessButtonStyle()) // ✅ Чтобы не перекрывалось NavigationLink
                            }
                        }
                    }
                    .onDelete { indexSet in
                        collections.remove(atOffsets: indexSet) // ✅ Удаление коллекции
                    }
                }
                .listStyle(PlainListStyle())

                Button(action: {
                    showingNewCollectionSheet = true // ✅ Показываем окно создания лукбука
                }) {
                    HStack {
                        Image(systemName: "plus.circle.fill")
                        Text("Добавить новый лукбук")
                    }
                    .font(.headline)
                    .foregroundColor(.blue)
                    .padding()
                }
            }
            .sheet(isPresented: $showingNewCollectionSheet) {
                NewCollectionView(collections: $collections, isPresented: $showingNewCollectionSheet)
            }
        }
    }

    // ✅ Функция скрытия клавиатуры
    private func hideKeyboard() {
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
}
