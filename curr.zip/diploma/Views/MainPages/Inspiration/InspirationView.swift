import SwiftUI

struct InspirationView: View {
    @StateObject private var viewModel = InspirationViewModel() // ✅ Используем ViewModel
    @State private var showingCommentSheet: Bool = false
    @State private var selectedPostIndex: Int?

    var body: some View {
        NavigationView {
            ScrollView {
                LazyVStack(spacing: 20) {
                    ForEach(viewModel.posts.indices, id: \.self) { index in
                        PostView(post: $viewModel.posts[index]) // ✅ Убираем `viewModel`
                            .onTapGesture {
                                selectedPostIndex = index
                                showingCommentSheet = true
                            }
                    }
                }
                .padding()
            }
            .navigationTitle("Inspiration")
        }
        .sheet(isPresented: $showingCommentSheet) {
            if let index = selectedPostIndex {
                CommentsView(post: $viewModel.posts[index]) // ✅ Передаем `@Binding`
            }
        }
    }
}
