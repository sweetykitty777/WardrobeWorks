import SwiftUI

struct OutfitCard: View {
    var outfit: Outfit

    var body: some View {
        VStack {
          /*  if let imageName = item.image_str, let image = UIImage(named: imageName) {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 100, height: 100)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
            } else {
                Image(systemName: "photo")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 100, height: 100)
                    .foregroundColor(.gray)
            }*/
    
            if let imageName = outfit.imageName, let image = UIImage(named: imageName){
                Image(uiImage: image)
                    .resizable()
                    .scaledToFit()
                    .frame(height: 200)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                    .shadow(radius: 4)
            } else {
                Image(systemName: "photo") // ✅ Заглушка для отсутствующих изображений
                    .resizable()
                    .scaledToFit()
                    .frame(height: 200)
                    .foregroundColor(.gray)
            }

            Text(outfit.name)
                .font(.headline)
                .padding(.top, 8)

            Text("\(outfit.outfitItems.count) вещей")
                .font(.subheadline)
                .foregroundColor(.gray)

            Divider()
        }
        .background(Color.white)
        .cornerRadius(12)
        .padding(.bottom, 10)
    }
}

/*
struct OutfitCard: View {
    var outfit: Outfit

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(outfit.name)
                .font(.headline)
            
            // ✅ Холст с вещами
            ZStack {
                Color.white
                    .cornerRadius(10)
                    .shadow(radius: 2)
                    .frame(height: 200)

                ForEach(outfit.outfitItems, id: \.id) { item in
                    Image(item.imageName)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 80, height: 80)
                        .position(x: item.position.x, y: item.position.y)
                        .rotationEffect(.degrees(item.rotation))
                        .scaleEffect(item.scale)
                }
            }
            .padding(.vertical, 5)
        }
        .padding()
        .background(Color.white)
        .cornerRadius(10)
        .shadow(radius: 2)
    }
}

*/
