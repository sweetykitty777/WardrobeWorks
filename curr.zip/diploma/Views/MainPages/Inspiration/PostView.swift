import SwiftUI

struct PostView: View {
    @Binding var post: Post // ✅ Используем `@Binding` для работы с `Post`
/*
    if let imageName = outfit.imageName, let image = UIImage(named: imageName){
        Image(uiImage: image)
            .resizable() ?? <#default value#>
            .scaledToFit()
            .frame(height: 200)
            .clipShape(RoundedRectangle(cornerRadius: 10))
            .shadow(radius: 4)
    } else {
        Image(systemName: "photo") // ✅ Заглушка для отсутствующих изображений
            .resizable()
            .scaledToFit()
            .frame(height: 200)
            .foregroundColor(.gray)
    }*/
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            if let imageName = post.outfit.imageName, var image = UIImage(named: post.outfit.imageName ??  "photo") {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFit()
                    .frame(height: 300)
                    .clipShape(RoundedRectangle(cornerRadius: 15))
            } else {
                Image(systemName: "photo")
                    .resizable()
                    .scaledToFit()
                    .frame(height: 300)
                    .foregroundColor(.gray)
            }

            Text(post.outfit.name)
                .font(.headline)
                .padding(.horizontal)

            HStack {
                Button(action: {
                    post.likes += 1 // ✅ Лайкаем пост через `@Binding`
                }) {
                    HStack {
                        Image(systemName: "heart.fill")
                            .foregroundColor(.red)
                        Text("\(post.likes)")
                    }
                }

                Spacer()

                Button(action: {
                    // ✅ Открытие комментариев
                }) {
                    HStack {
                        Image(systemName: "message.fill")
                            .foregroundColor(.blue)
                        Text("\(post.comments.count)")
                    }
                }
            }
            .padding(.horizontal)
        }
        .padding()
        .background(Color.white)
        .clipShape(RoundedRectangle(cornerRadius: 15))
        .shadow(radius: 3)
    }
}
