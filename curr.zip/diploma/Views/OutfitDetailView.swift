import Foundation
import SwiftUI

struct OutfitDetailView: View {
    let outfit: Outfit

    var body: some View {
        
        
        VStack {
            // ✅ Отображаем изображение аутфита
            if let imageName = outfit.imageName, let image = UIImage(named: imageName){
             Image(uiImage: image)
                 .resizable()
                 .scaledToFit()
                 .frame(height: 200)
                 .clipShape(RoundedRectangle(cornerRadius: 10))
                 .shadow(radius: 4)
             } else {
                 Image(systemName: "photo") // ✅ Заглушка для отсутствующих изображений
                     .resizable()
                     .scaledToFit()
                     .frame(height: 200)
                     .foregroundColor(.gray)
             }
            Text(outfit.name)
                .font(.title)
                .fontWeight(.bold)
                .padding(.bottom, 10)

            Text("Состав аутфита:")
                .font(.headline)
                .padding(.horizontal)

            // ✅ Список вещей, входящих в аутфит
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 15) {
                    ForEach(outfit.outfitItems, id: \.id) { item in
                        VStack {
                            Image(item.imageName)
                                .resizable()
                                .scaledToFit()
                                .frame(width: 100, height: 100)
                                .clipShape(RoundedRectangle(cornerRadius: 10))

                            Text(item.name)
                                .font(.caption)
                                .foregroundColor(.black)
                        }
                    }
                }
                .padding(.horizontal)
            }

            Spacer()
        }
        .navigationTitle(outfit.name) // ✅ Заголовок страницы — название аутфита
        .navigationBarTitleDisplayMode(.inline)
    }
}
