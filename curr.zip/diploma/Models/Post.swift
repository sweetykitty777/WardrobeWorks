//
//  Post.swift
//  diploma
//
//  Created by Olga on 11.03.2025.
//

import Foundation

struct Post: Identifiable {
    let id = UUID()
    let outfit: Outfit // 🔥 Привязываем `Outfit` к посту
    var likes: Int = 0 // 🔥 Количество лайков
    var comments: [String] = [] // 🔥 Список комментариев
}
